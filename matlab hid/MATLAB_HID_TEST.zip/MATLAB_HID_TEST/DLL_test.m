%addpath('C:\..etc..');
% Display functions in library.
if not(libisloaded('usbhidlib'))
    loadlibrary('usbhidlib');
end
libfunctions('usbhidlib');
% NOTE: you can ignore the warning:
% "Warning: The data type 'hid_device_infoPtr' used by structure 
% hid_device_info does not exist." -- this is not true or a problem.

% see handout for info on the code needed: 







%unloadlibrary('usbhidlib');   % This unloads the dll when the program exits
                              % For developing the MatLab program, REM this
                              % out so it doesn't have to load the dll each
                              % time the pregram runs (saves time). 